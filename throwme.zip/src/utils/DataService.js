const DataService = () => [
  {
    id: 1,
    cardImage: "/assets/Paper map-cuate.svg",
    headline: "Find the nearest place for specific waste",
    btnDesc: "Find Location",
  },
  {
    id: 2,
    cardImage: "/assets/Paper map-cuate.svg",
    headline: "Create your own location for specific waste",
    btnDesc: "Create Location",
  },
  {
    id: 3,
    cardImage: "/assets/Paper map-cuate.svg",
    headline: "Find interesting articles and information about waste",
    btnDesc: "Find Article",
  },
  {
    id: 4,
    cardImage: "/assets/Paper map-cuate.svg",
    headline: "Find interesting articles and information about waste",
    btnDesc: "Find Article",
  },
];

export { DataService };
