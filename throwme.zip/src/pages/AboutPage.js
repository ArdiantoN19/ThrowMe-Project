import React from "react";
import About from "../components/About/About";

function AboutPage() {
  return (
    <div className="container">
      <About />
    </div>
  );
}

export default AboutPage;
